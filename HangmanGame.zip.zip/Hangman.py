import tkinter as tk
from tkinter import messagebox, font
import random
import math
import time

class HangmanGame:
    def __init__(self, root):
        self.root = root
        self.root.title("Hangman Game")
        self.root.geometry("700x600")
        
        # Set soft purple background
        self.bg_color = "#E6D0F2"
        self.root.configure(bg=self.bg_color)
        
        # Load Comic Sans Font
        self.comic_sans = font.Font(family="Comic Sans MS", size=12)
        self.title_font = font.Font(family="Comic Sans MS", size=24, weight="bold")
        self.hint_font = font.Font(family="Comic Sans MS", size=10, slant='italic')
        
        # Word list with hints
        self.word_with_hints = [
            ("PYTHON", "A popular programming language."),
            ("MARINA", "Means 'From the Sea' in latin"),
            ("RAINBOW", "The symbol of the LGBTQ+ community."),
            ("ASEXUALITY", "Typically defined as a lack of sexual attraction"),
            ("AROMANTICISM", "Typically defined as a lack of romantic attraction"),
            ("TRANSGENDER", "A person born in the wrong body identify as..."),
            ("NONBINARY", "A person who does not identify as either male or female is..."),
            ("BISEXUAL", "A person who is attracted to both men and women is..."),
            ("MISANDRI", "The male version of 'misogyny' is..."),
            ("ALLY", "A cis-straight person who supports the LGBTQ+ community is an..."),
            ("CLAUDE", "The best AI tool for coding is called...")
        ]
        
        # Game variables
        self.word = ""
        self.hint = ""
        self.guessed_letters = []
        self.attempts_left = 12
        self.flag_animation_id = None
        self.flag_wave_offset = 0
        
        self.setup_ui()
        self.start_new_game()

    def setup_ui(self):
        # Title
        self.title_label = tk.Label(
            self.root,
            text="Hangman Game",
            font=self.title_font,
            bg=self.bg_color
        )
        self.title_label.pack(pady=10)

        # Game area (hangman display and words)
        self.game_frame = tk.Frame(self.root, bg=self.bg_color)
        self.game_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)

        # Hangman display on left
        self.hangman_frame = tk.Frame(self.game_frame, bg=self.bg_color)
        self.hangman_frame.pack(side=tk.LEFT, padx=10)

        self.hangman_display = tk.Canvas(
            self.hangman_frame,
            width=250,
            height=300,
            bg=self.bg_color,
            highlightthickness=0
        )
        self.hangman_display.pack()

        # Now draw the Pride flag
        self.draw_pride_flag()

        # Word and guessing area on right
        self.word_frame = tk.Frame(self.game_frame, bg=self.bg_color)
        self.word_frame.pack(side=tk.LEFT, padx=10, fill=tk.BOTH, expand=True)

        # Hint display
        self.hint_display = tk.Label(
            self.word_frame,
            text="",
            font=self.hint_font,
            bg=self.bg_color,
            wraplength=300,
            justify=tk.LEFT
        )
        self.hint_display.pack(pady=10, anchor=tk.W)

        # Word display
        self.word_display = tk.Label(
            self.word_frame,
            text="",
            font=self.comic_sans,
            bg=self.bg_color
        )
        self.word_display.pack(pady=10)

        # Attempts left display
        self.attempts_display = tk.Label(
            self.word_frame,
            text="",
            font=self.comic_sans,
            bg=self.bg_color
        )
        self.attempts_display.pack(pady=5)

        # Guess entry
        self.guess_frame = tk.Frame(self.word_frame, bg=self.bg_color)
        self.guess_frame.pack(pady=10)

        self.guess_label = tk.Label(
            self.guess_frame,
            text="Enter a letter:",
            font=self.comic_sans,
            bg=self.bg_color
        )
        self.guess_label.pack(side=tk.LEFT, padx=5)

        self.guess_entry = tk.Entry(
            self.guess_frame,
            font=self.comic_sans,
            width=5
        )
        self.guess_entry.pack(side=tk.LEFT, padx=5)
        self.guess_entry.bind("<Return>", lambda event: self.make_guess())

        self.guess_button = tk.Button(
            self.guess_frame,
            text="Guess",
            font=self.comic_sans,
            command=self.make_guess
        )
        self.guess_button.pack(side=tk.LEFT, padx=5)

        # Guessed letters display
        self.guessed_display = tk.Label(
            self.word_frame,
            text="",
            font=self.comic_sans,
            bg=self.bg_color,
            wraplength=300,
            justify=tk.LEFT
        )
        self.guessed_display.pack(pady=10, anchor=tk.W)

        # New game button
        self.new_game_button = tk.Button(
            self.root,
            text="New Game",
            font=self.comic_sans,
            command=self.start_new_game,
        )
        self.new_game_button.pack(pady=10)
    
    def start_flag_animation(self):
        # Cancel any existing animation
        if self.flag_animation_id:
            self.root.after_cancel(self.flag_animation_id)
            
        # Start new animation cycle
        self.animate_flag()
        
    def animate_flag(self):
        # Update wave offset
        self.flag_wave_offset += 0.2
        
        # Redraw the hangman scene with updated flag
        self.draw_hangman()
        
        # Continue animation
        self.flag_animation_id = self.root.after(50, self.animate_flag)

    def start_new_game(self):
        # Choose random word and hint
        self.word, self.hint = random.choice(self.word_with_hints)
        self.guessed_letters = []
        self.attempts_left = 12
        
        # Update displays
        self.update_displays()
        self.guess_entry.delete(0, tk.END)
        self.guess_entry.focus()
        
        # Start flag animation
        self.start_flag_animation()

    def update_displays(self):
        # Update hint display
        self.hint_display.config(text = f"Hint: {self.hint}")
        
        # Update word display
        displayed_word = ""
        for letter in self.word:
            if letter in self.guessed_letters:
                displayed_word += letter + " "
            else:
                displayed_word += "_ "
        self.word_display.config(text = displayed_word)
        
        # Update guessed letters display
        if self.guessed_letters:
            guessed_text = "Guessed letters: " + ", ".join(self.guessed_letters)
        else: 
            guessed_text = "Guessed letters: None yet!"
        self.guessed_display.config(text = guessed_text)
        
        # Update attempts display
        self.attempts_display.config(text = f"Attempts left: {self.attempts_left}")
        
        # Update hangman figure
        self.draw_hangman()
        
    def draw_hangman(self):
        self.hangman_display.delete("all")
        
        # Draw platform
        if self.attempts_left <= 11:    # Failed attempt 1: horizontal base
            self.hangman_display.create_line(50, 250, 150, 250, width = 3)
            
        if self.attempts_left <= 10:    # Failed attempt 2: vertical post
            self.hangman_display.create_line(100, 250, 100, 50, width = 3)
        
        if self.attempts_left <= 9:     # Failed attempt 3: horizontal beam
            self.hangman_display.create_line(100, 50, 150, 50, width = 3)
            
        # Draw animated pride flag when we have the pole (after failed attempt 2)
        if self.attempts_left <= 10:
            self.draw_pride_flag()
        
        if self.attempts_left <= 8:     # Failed attempt 4: noose
            self.hangman_display.create_line(150, 50, 150, 70, width = 2)
            
        if self.attempts_left <= 7:     # Failed attempt 5: head
            self.hangman_display.create_oval(135, 70, 165, 100, width = 2)
        
        if self.attempts_left <= 6:     # Failed attempt 6: body
            self.hangman_display.create_line(150, 100, 150, 150, width = 2)
            
        if self.attempts_left <= 5:     # Failed attempt 7: left arm
            self.hangman_display.create_line(150, 110, 130, 130, width = 2)
            
        if self.attempts_left <= 4:     # Failed attempt 8: right arm
            self.hangman_display.create_line(150, 110, 170, 130, width = 2)
            
        if self.attempts_left <= 3:     # Failed attempt 9: left leg
            self.hangman_display.create_line(150, 150, 130, 180, width = 2)
            
        if self.attempts_left <= 2:     # Failed attempt 10: right leg
            self.hangman_display.create_line(150, 150, 170, 180, width = 2)
            
        if self.attempts_left <= 1:     # Failed attempt 11: X eyes
            self.hangman_display.create_line(142, 80, 148, 86, width = 2) # Left eye X (part 1)
            self.hangman_display.create_line(142, 86, 148, 80, width = 2) # Left eye X (part 2)
            self.hangman_display.create_line(152, 80, 158, 86, width = 2) # Right eye X (part 1)
            self.hangman_display.create_line(152, 86, 158, 80, width = 2) # Right eye X (part 2)
        
        if self.attempts_left <= 0:     # Failed attempt 12: sad mouth
            self.hangman_display.create_arc(140, 90, 160, 100, start = 0, extent = -180, style = tk.ARC, width = 2)
            
    def draw_pride_flag(self):
        # Position the flag at the top-left corner of the screen
        flag_x = 10   # X-coordinate near the left edge of the window
        flag_y = 10   # Y-coordinate near the top edge of the window
        flag_width = 50
        flag_height = 30

        # Draw Pride flag colors (6 stripes)
        colors = ["#FF0000", "#FF7F00", "#FFFF00", "#00FF00", "#0000FF", "#8D00FF"]

        # Calculate stripe height
        stripe_height = flag_height / len(colors)

        # Draw each colored stripe with wave effect
        for i, color in enumerate(colors):
            points = []
            # Left edge of flag
            points.append(flag_x)
            points.append(flag_y + i * stripe_height)

            # Create wave effect for each point along the flag
            for x in range(5):  # 5 points across flag width
                wave_x = flag_x + (x + 1) * (flag_width / 5)
                wave_factor = x / 5  # Define wave_factor here
                wave_y = flag_y + i * stripe_height + math.sin(self.flag_wave_offset + x / 2) * 3 * wave_factor
                points.append(wave_x)
                points.append(wave_y)

            # Bottom right point
            points.append(flag_x + flag_width)
            points.append(flag_y + (i + 1) * stripe_height + math.sin(self.flag_wave_offset + 1) * 3)

            # Bottom points with wave effect (reverse)
            for x in range(5, 0, -1):
                wave_x = flag_x + x * (flag_width / 5)
                wave_factor = x / 5  # Define wave_factor here as well
                wave_y = flag_y + (i + 1) * stripe_height + math.sin(self.flag_wave_offset + x / 2) * 3 * wave_factor
                points.append(wave_x)
                points.append(wave_y)

            # Draw the polygon for this stripe
            self.hangman_display.create_polygon(points, fill=color, outline="")

        # Draw flag pole side
        self.hangman_display.create_line(flag_x, flag_y, flag_x, flag_y + flag_height, width=2)

    def make_guess(self):
        guess = self.guess_entry.get().upper()
        self.guess_entry.delete(0, tk.END)
        
        if not guess.isalpha() or len(guess) != 1:
            messagebox.showwarning("Invalid Input", "Please enter a single letter.")
            return
        
        if guess in self.guessed_letters:
            messagebox.showwarning("Already Guessed", "You have already guessed that letter.")
            return
        
        self.guessed_letters.append(guess)
        
        if guess not in self.word:
            self.attempts_left -= 1
            
        self.update_displays()
        
        # Check win/loss conditions
        all_letters_guessed = all(letter in self.guessed_letters for letter in self.word)
        
        if all_letters_guessed:
            # Stop the animation before showing message
            if self.flag_animation_id:
                self.root.after_cancel(self.flag_animation_id)
            messagebox.showinfo("You win!", f"Congratulations! The word was {self.word}")
            self.start_new_game()
            
        if self.attempts_left == 0:
            # Stop the animation before showing message
            if self.flag_animation_id:
                self.root.after_cancel(self.flag_animation_id)
                self.flag_animation_id = None
            messagebox.showinfo("You lose", f"Sorry, you lost! The word was {self.word}")
            self.start_new_game()
            
if __name__ == "__main__":
    root = tk.Tk()
    game = HangmanGame(root)
    root.mainloop()









